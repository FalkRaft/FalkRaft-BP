import { world , system } from '@minecraft/server';

console.log('test')